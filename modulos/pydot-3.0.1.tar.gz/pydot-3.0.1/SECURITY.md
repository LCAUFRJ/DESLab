<!--
SPDX-FileCopyrightText: 2024 pydot contributors

SPDX-License-Identifier: MIT
-->

# Security Policy
## Reporting a vulnerability

If it's a real vulnerability, report it via `lukaszlapinski7 <(at)> gmail <(dot)> com`.

For minor issues, please use the following link: https://github.com/pydot/pydot/issues

They will be looked into as soon as possible.
