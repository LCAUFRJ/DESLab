GIS Shapefile
=============
.. automodule:: networkx.readwrite.nx_shp
.. autosummary::
   :toctree: generated/

   read_shp
   write_shp


