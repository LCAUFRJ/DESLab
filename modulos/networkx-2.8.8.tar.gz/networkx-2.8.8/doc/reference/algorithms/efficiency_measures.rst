**********
Efficiency
**********

.. automodule:: networkx.algorithms.efficiency_measures
.. autosummary::
   :toctree: generated/

   efficiency
   local_efficiency
   global_efficiency
