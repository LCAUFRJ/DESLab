******
Triads
******

.. automodule:: networkx.algorithms.triads
.. autosummary::
   :toctree: generated/

   triadic_census
   random_triad
   triads_by_type
   triad_type
   is_triad
   all_triads
   all_triplets
