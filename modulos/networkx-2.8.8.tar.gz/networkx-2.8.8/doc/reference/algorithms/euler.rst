********
Eulerian
********

.. automodule:: networkx.algorithms.euler
.. autosummary::
   :toctree: generated/

   is_eulerian
   eulerian_circuit
   eulerize
   is_semieulerian
   has_eulerian_path
   eulerian_path
