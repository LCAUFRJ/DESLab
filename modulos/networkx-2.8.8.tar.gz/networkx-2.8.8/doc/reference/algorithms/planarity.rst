*********
Planarity
*********

.. automodule:: networkx.algorithms.planarity
.. autosummary::
   :toctree: generated/

   check_planarity
   is_planar
   PlanarEmbedding
