.. _nxep_list:

NXEPs
*****

NetworkX Enhancement Proposals (NXEPs) document major changes or proposals.

.. toctree::
   :maxdepth: 1

   nxep-0000
   nxep-0001
   nxep-0002
   nxep-0003
   nxep-0004

.. toctree::
   :hidden:

   nxep-template
