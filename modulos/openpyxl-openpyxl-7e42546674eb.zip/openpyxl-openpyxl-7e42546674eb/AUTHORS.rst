This project was started by Eric Gazoni. In 2013 Charlie Clark became
co-maintainer of the project.

It was initiallay *heavily* inspired by the PHPExcel library:
http://www.phpexcel.net/

Thanks to all those who participate in the project (in alphabetical order):

* Stephane Bard
* Day Barr
* Stefan Behnel
* Bernt R. Brenna
* Sven Burk
* Max Bolingbroke
* Anders Chrigstrom
* ccoacley
* Maarten De Paepe
* Etienne Desautels
* Dmitriy Chernyshov
* Eric Chlebek
* Alexandre Fayolle
* Don Freeman
* Eric Gazoni
* Brice Gelineau
* Mark Gemmill
* Alex Gronholm
* Yaroslav Halchenko
* Fumito Hamamura
* Khchine Hamza
* Josh Haywood
* Jeff Holman
* Brent Hoover
* Eric Hurkman
* Jean Pierre Huart
* JarekPS
* Heikki Junes
* Chi Ho Kwok
* Yingjie Lan
* Detlef Lannert
* Laurent Laporte
* Nicholas Laver
* Greg Lehmann
* Adam Lofts
* Marko Loparic
* Samuel Loretan
* Amin Mirzaee
* Adam Morris
* aceMueller
* Gabi Nagy
* Thomas Nygards
* Felipe Ochoa
* Jun Omae
* Waldemar Osuch
* Jonathan Peirce
* Sergey Pikhovkin
* Ted Pollari
* Elias Rabel
* Rick Rankin
* ramn_se
* Philip Roche
* Wojciech Rola
* James Smagala
* Wolfgane Scherer
* Joseph Tate
* Gar Thompson
* Dieter Vandenbussche
* Paul Van Der Linden
* Gerald Van Huffelen
* Koert van der Veer
* Laurent Vasseur
* Kay Webber
* Shibukawa Yoshiki

Project logo designed by Eric Gazoni, font by claudeserieux
(http://www.dafont.com/profile.php?user=337503)
